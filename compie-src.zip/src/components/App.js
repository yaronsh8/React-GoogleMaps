import React, {Component} from 'react';
import TopBar from './TopBar';
import MyLocation from './MyLocation';
import BranchList from './BranchList';
import Nearest from './Nearest';

export default class App extends Component {

    constructor(props) {
        super(props);

        this.state = {
            original_list: [],
            displayed_list: []
        };

        window
            .fetch('data.json')
            .then(response => response.json())
            .then(res => this.setState({original_list: res}))
    }

    update_branch_list(sorted_list) {
        this.setState({displayed_list: sorted_list})
    }

    render() {
        let myLat,
            myLng;

        return (
            <div className="container">
                <TopBar/>
                <MyLocation
                    update_myLocation_cb_prop={(lat, lng) => {
                    myLat = lat;
                    myLng = lng;
                }}
                    original_list_prop={this.state.original_list}
                    update_branch_list_cb_prop={sorted_list => this.update_branch_list(sorted_list)}/>

                <Nearest displayed_list_prop={this.state.displayed_list}/>

                <BranchList displayed_list_prop={this.state.displayed_list}/>

            </div>
        )
    }
}
