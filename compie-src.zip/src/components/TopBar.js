import React from 'react';

export default() => {
    return (
        <div className="bg-primary">
            <h1>SuperMarket Radar</h1>
        </div>
    )
}