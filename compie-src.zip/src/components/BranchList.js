import React, {Component} from 'react';

export default class BranchList extends Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div>
                {this.props.displayed_list_prop.length > 0 && <div>
                    <h2>Branch List:</h2>
                    <table className="table table-striped">
                        <thead>
                            <tr>
                                <th>network</th>
                                <th>name</th>
                                <th>location</th>
                                <th>distance</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this
                                .props
                                .displayed_list_prop
                                .map(item => {
                                    return (
                                        <tr key={item.name}>
                                            <td>
                                                {item.network}
                                            </td>
                                            <td>
                                                {item.name}
                                            </td>
                                            <td>
                                                {item.location}
                                            </td>
                                            <td>
                                                {item.distance}
                                            </td>
                                        </tr>
                                    )
                                })}

                        </tbody>
                    </table>
                </div>}
            </div>
        )
    }
}