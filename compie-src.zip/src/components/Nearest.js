import React, {Component} from 'react';

export default class BranchList extends Component {
    constructor(props) {
        super(props)
    }

    findNearestBranches() {
        //filter for branches up to 50km
        let nearestBranches = [];
        if (this.props.displayed_list_prop.length) {
            nearestBranches = this
                .props
                .displayed_list_prop
                .filter(item => {
                    return (item.distance <= 50)
                })
        }
        return nearestBranches;
    }

    findNearestNetwork(nearestBranches) {
        if (nearestBranches.length == 0) {
            return {network: "none", count: -1}
        }

        let tallyArr = []
        nearestBranches.forEach(item => {
            tallyArr.push(item.network)
        })
        // reduce to an object: {mega:2 , shufersal:3}
        if (tallyArr.length != 0) {
            let countObj = tallyArr.reduce((tally, network) => {
                tally[network] = (tally[network] || 0) + 1;
                return tally;
            }, {})

            //find the best network
            let maxNum = 0;
            let bestNetwork = "";
            for (let item in countObj) {
                if (countObj[item] > maxNum) {
                    maxNum = countObj[item]
                    bestNetwork = item
                }
            }
            return {network: bestNetwork, count: maxNum}

        }
    }

    render() {
        let best = {
            network: "",
            count: 0
        }

        if (this.props.displayed_list_prop.length != 0) {
            best = this.findNearestNetwork(this.findNearestBranches());

        }
        return (
            <div>
                {best.count == -1 && <h2 className="bg-warning">No supermarkets in 50 km radius</h2>
}
                {best.count > 0 && <h2 className="bg-success">
                    {best.network}
                    {' '}
                    has the best spread near you - {best.count}
                    {' '}
                    branches in up to 50km radius
                </h2>
}

            </div>
        )
    }
}