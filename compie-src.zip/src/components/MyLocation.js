import React, {Component} from 'react';

export default class MyLocation extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div>
                <h2>My Location:</h2>
                <input
                    className="form-control"
                    placeholder="My Location"
                    id="autocomplete"
                    type="text"/>
                <button
                    className="btn btn-primary"
                    onClick={(e) => {
                    this.sortBranches(e)
                }}>Send</button>

            </div>
        )
    }

    componentDidMount() {
        this.initAutocomplete();
    }

    updateMyLocation(lat, lng) {
        this
            .props
            .update_myLocation_cb_prop(lat, lng);
    }

    initAutocomplete() {
        let inputField = document.getElementById('autocomplete');
        //add autocomplete object to 'this'
        this.autocomplete = new google
            .maps
            .places
            .Autocomplete(inputField, {types: ['geocode']});

    }

    sortBranches(e) {

        //get myLocation coordinates
        let locationDetails = this
            .autocomplete
            .getPlace();

        if (!locationDetails) {
            return
        }

        //use built-in methods lat() & lng()
        let myCoords = {
            lat: locationDetails
                .geometry
                .location
                .lat(),
            lng: locationDetails
                .geometry
                .location
                .lng()
        }
        // add 'branchList and' 'network' properties to 'this'
        this.branchList = [];
        this.network = "";

        //calc distance for each branch and populate branchList
        this
            .props
            .original_list_prop
            .map((item) => {
                this.network = item.name;
                return (item.branches.map((branch) => {
                    this
                        .branchList
                        .push({
                            network: this.network,
                            name: branch.name,
                            location: branch.location,
                            distance: this.getDistance(myCoords, branch)
                        })
                }))
            })

        //sort the array in place
        this.branchList = this.sortArray(this.branchList);

        //use the update branch list callback
        this
            .props
            .update_branch_list_cb_prop(this.branchList);

    }

    getDistance(myCoords, branch) {
        //courtesy of google :-)
        let R = 6371; // Radius of the earth in km
        let dLat = deg2rad(branch.lat - myCoords.lat); // deg2rad below
        let dLon = deg2rad(branch.lng - myCoords.lng);
        let a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(deg2rad(myCoords.lat)) * Math.cos(deg2rad(branch.lat)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        let d = R * c; // Distance in km
        return Math.floor(d);

        function deg2rad(deg) {
            return deg * (Math.PI / 180)
        }
    }

    sortArray(arr) {
        return (arr.sort(function (a, b) {
            return parseFloat(a.distance) - parseFloat(b.distance);
        }));

    }
}
